package com.example.controller;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.models.Docente;
import com.example.services.DocenteService;

@RestController
@RequestMapping(path = "/docente")
public class DocenteController {
	
    @Autowired
    private DocenteService docenteService;

    @GetMapping
    public ResponseEntity<ArrayList<Docente>> getAll() {
		return ResponseEntity.ok(docenteService.getAll());
	}
    
    @PostMapping
    public void saveUpdate(@RequestBody Docente docente) {
        docenteService.save(docente);
    }

    @PutMapping
    public void Update(@RequestBody Docente docente) {
        docenteService.update(docente);
    }

    @DeleteMapping("/{docenteId}")
    public ResponseEntity<String> delete(@PathVariable("docenteId") Long docenteId) {
        docenteService.delete(docenteId);
        return ResponseEntity.ok("Docente Eliminado");
    }

    @GetMapping("/{docenteId}")
    public Optional<Docente> getBId(@PathVariable("docenteId") Long docenteId) {
        return docenteService.getDocentes(docenteId);
    }

}