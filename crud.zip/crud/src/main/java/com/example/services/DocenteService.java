package com.example.services;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.models.Docente;
import com.example.repositories.DocenteRepository;

@Service
public class DocenteService {
	
    @Autowired
    DocenteRepository docenteRepository;

    public ArrayList<Docente> getAll(){
		return (ArrayList<Docente>)docenteRepository.findAll();
	}

    public Optional<Docente> getDocentes(Long id) {
        return docenteRepository.findById(id);
    }

    public void save(Docente docente) {
        docenteRepository.save(docente);
    }

    public void update(Docente docente) {
        if (docenteRepository.existsById(docente.getId())) {
            docenteRepository.save(docente);
        }
    }

    public void delete(Long id) {
        docenteRepository.deleteById(id);
    }
}